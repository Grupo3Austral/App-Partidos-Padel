import{a,b,c,d,e,g as f}from"./chunk-G4GOZ2R2.js";import"./chunk-VI73JOY6.js";f();export{c as Headers,d as Request,e as Response,b as default,a as fetch};
