import {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
} from "./chunk-IZ6MSXLE.js";
import "./chunk-QEE7QVES.js";
import "./chunk-ZX72GS7T.js";
import "./chunk-BGWCTVHG.js";
export {
  MENU_BACK_BUTTON_PRIORITY,
  OVERLAY_BACK_BUTTON_PRIORITY,
  blockHardwareBackButton,
  shouldUseCloseWatcher,
  startHardwareBackButton
};
