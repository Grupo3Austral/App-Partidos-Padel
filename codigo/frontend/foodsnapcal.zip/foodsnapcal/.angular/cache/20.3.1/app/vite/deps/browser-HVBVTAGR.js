import {
  Headers,
  Request,
  Response,
  browser_default,
  fetch,
  init_browser
} from "./chunk-YBWKDK6H.js";
import "./chunk-BGWCTVHG.js";
init_browser();
export {
  Headers,
  Request,
  Response,
  browser_default as default,
  fetch
};
